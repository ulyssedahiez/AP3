<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>voyageurs</title>
  <link rel="stylesheet" type="text/css" href="./style.css" media="all"/>
  <script src="script.js"></script>
</head>
<body>
  <h2>billet</h2>
</br>
<?php include("navbar.php"); ?>


</body>
</html>