<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <title>intero web</title>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
</head>
<body>
  <h3>Question de cours</h3>
  <h5>1)</h5>
  <p>ce texte est normal</p>
  <small>Ce texte est écrit très petit</small>
  </br>
  <h5>2)</h5>

    <p>la balise < br > est un exemple de balise simple. pour passer à la ligne</p>
    <p> la balise double < body > est une balise qui délimite de corp de la page.</p>
    </br>
  <h5>3)</h5>
  <p> la méthode get peut prendre dans l'url des paramètres ce que ne peut pas faire la méthode post.</br> le protocole session quant à lui sert à faire une session pour retenir des information mais uniquement dans sa session</p>
  </br>
  <h5>3)</h5>
<?php
function addition($nombre1, $nombre2)
{
    echo $nombre1+$nombre2;
}
?>
</br>
  <h3>Sujet : </h3>
  </br>



</body>
</html>