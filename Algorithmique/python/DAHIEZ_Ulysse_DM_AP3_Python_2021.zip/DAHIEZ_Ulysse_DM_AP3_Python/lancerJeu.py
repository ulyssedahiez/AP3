import menu
menu.menu()

#pensez à ouvrir la fenetre en assez grand.
