
double generateDouble ();

double* newTabl(double* tableau);

double* triSelection(double* tableau, double* tableauTrie);

int estDans(double monNombre, double* tableau, int* lecture);

double* dupliquertableau(double* tableau1, double* tableau2);

int plusProche(double* tableau, double valeur);

int chercherNombre(double* tableau, double nombre);